import java.util.ArrayList;
import java.util.Vector;

public class ReactiveAgent 
{
		GridClient gc;
		
		public ReactiveAgent()
		{
			gc = new GridClient("localhost", 7237);
		}
		public String think(SensoryPacket sp)
		{
			String a;
			if(sp.getInventory().contains('+'))
				a = "u";
			else if(sp.getGroundContents().contains('+'))
				a = "g";
			else
				a = sp.getSmell();
			return a;
		}
		public void run()
		{
			while(true)
			{
				SensoryPacket sp = gc.getSensoryPacket();
				String action = think(sp);
				gc.effectorSend(action);
			}
		}
		private String eyeOfSauron(ArrayList<ArrayList<Vector<Character>>> visField)
		{
			// if there is a wall in front of/behind you, turn left/right. If there is no longer a wall, turn and check for cheese then move in that direction. 
			return null;
		}
		public static void main(String[] args)
		{
			ReactiveAgent ra = new ReactiveAgent();
			ra.run();
		}
		
}
