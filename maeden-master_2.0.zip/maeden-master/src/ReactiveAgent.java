import java.util.ArrayList;
import java.util.Vector;

public class ReactiveAgent 
{
		GridClient gc;
		
		public ReactiveAgent()
		{
			gc = new GridClient("localhost", 7237);
		}
		public String think(SensoryPacket sp)
		{
			String a;
			System.out.println(sp.getSmell());
			if(sp.getInventory().contains('+'))
				a = "u";
			else if(sp.getGroundContents().contains('+'))
				a = "g";
			// Check if obstacle and move
			/*else if(sp.getSmell().contains("f") && !sp.visualArray.get(4).get(2).contains('*'))
			{
				a = "f";
			}*/
			/*else if(sp.getSmell().contains("r") && !sp.visualArray.get(5).get(3).contains('*'))
			{
				a = "r";
			}*/
			/*else if(sp.getSmell().contains("l") && !sp.visualArray.get(5).get(1).contains('*'))
			{
				a = "l";
			}*/
			//check wall in front
			else if(sp.visualArray.get(4).get(2).contains('*'))
			{
				//turn left or right
				/*long rand = Math.round(Math.random());
				System.out.println("value: " + rand);
				if(rand == 0)
					a = "l";
				else*/
					a = "l";
			}
			//traverse obstacle to right
			else if(sp.visualArray.get(5).get(3).contains('*')&& !sp.getSmell().contains("l"))
			{
				a = "f";
			}
			else if(sp.visualArray.get(6).get(3).contains('*') && !sp.getSmell().contains("f"))
			{
				a = "r";
			}
			else if(sp.visualArray.get(4).get(3).contains('*'))
			{
				a = "f";
			}
			//traverst to left
			//traverse obstacle to right
			/*else if(sp.visualArray.get(5).get(1).contains('*'))
			{
				a = "f";
			}
			else if(sp.visualArray.get(6).get(1).contains('*'))
			{
				a = "l";
			}
			else if(sp.visualArray.get(4).get(1).contains('*'))
			{
				a = "f";
			}*/
			//follow smell
			else	
			a = sp.getSmell();
			if(a.contains("b"))
				a = "l";
			System.out.println("Command: "+a);
			return a;
		}
		public void run()
		{
			while(true)
			{
				SensoryPacket sp = gc.getSensoryPacket();
				String action = think(sp);
				gc.effectorSend(action);
			}
		}
		public static void main(String[] args)
		{
			ReactiveAgent ra = new ReactiveAgent();
			ra.run();
		}
		
}
