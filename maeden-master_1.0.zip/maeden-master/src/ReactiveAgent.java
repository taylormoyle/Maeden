public class ReactiveAgent 
{
		GridClient gc;
		
		public ReactiveAgent()
		{
			gc = new GridClient("localhost", 7237);
		}
		private String think(SensoryPacket sp)
		{
			//else if(sp.visualArray.get().get().contains('*'))
			//!sp.visualArray.get().get().contains('*')
			String a = sp.getSmell();
			String smell = sp.getSmell();
			String itemSmell = null;
			
			// win condition
			if(sp.getInventory().contains('+'))
				return "u";
			else if(sp.getGroundContents().contains('+') || sp.getGroundContents().contains('T') || sp.getGroundContents().contains('K'))
				return "g";
			
				itemSmell = itemCheck(sp, 'T');
				if(itemSmell == null)
					itemSmell = itemCheck(sp, 'K');
				if(itemSmell != null)
				{
					a = itemSmell;
					smell = itemSmell;
				}
			
			if(sp.visualArray.get(4).get(2).contains('@') && sp.getInventory().contains('T'))
					a = "u";
			else if(sp.visualArray.get(4).get(2).contains('#') && sp.getInventory().contains('K'))
				a = "u";
			else if(sp.visualArray.get(5).get(1).contains('@') && sp.getInventory().contains('T'))
				a = "l";
			else if(sp.visualArray.get(5).get(3).contains('@') && sp.getInventory().contains('T'))
				a = "r";
			else if(sp.visualArray.get(5).get(1).contains('#') && sp.getInventory().contains('K'))
				a = "l";
			else if(sp.visualArray.get(5).get(3).contains('#') && sp.getInventory().contains('K'))
				a = "r";
			else if(smell.contains("l"))
				a = "l";
			else if (smell.contains("f") && !(sp.visualArray.get(4).get(2).contains('*') || sp.visualArray.get(4).get(2).contains('@') || sp.visualArray.get(4).get(2).contains('#')))
				a = "f";
			else if(sp.visualArray.get(4).get(2).contains('*') || sp.visualArray.get(4).get(2).contains('@') || sp.visualArray.get(4).get(2).contains('#'))
				a = "l";
			else if(sp.visualArray.get(5).get(3).contains('*') || sp.visualArray.get(5).get(3).contains('@') || sp.visualArray.get(5).get(3).contains('#'))
				a = "f";
			else if(sp.visualArray.get(5).get(1).contains('*') || sp.visualArray.get(5).get(1).contains('@') || sp.visualArray.get(5).get(1).contains('#'))
				a = "f";
			else if(sp.visualArray.get(6).get(3).contains('*') || sp.visualArray.get(6).get(3).contains('@') || sp.visualArray.get(6).get(3).contains('#'))
				a = "r";
			else if(sp.visualArray.get(4).get(3).contains('*') || sp.visualArray.get(4).get(3).contains('@') || sp.visualArray.get(4).get(3).contains('#'))
				a = "f";
			else if(smell.contains("b"))
				a = "l";
			System.out.println("S:"+smell+" C:"+a);
			return a;
		}
		private String itemCheck(SensoryPacket sp, char item)
		{
			int x = 0;
			int y = 0;
			boolean found = false;
			for(int i = 0; i <= 6; i++)
			{
				for(int j = 0; j <= 4; j++)
				{
					if(sp.visualArray.get(i).get(j).contains(item))
					{
						found = true;
						x = i;
						y = j;
					}
					if(found)
						break;
				}
				if(found)
					break;
			}
			if(found)
			{
				if(x <= 4)
					return "f";
				else if(x == 5 && y < 2)
					return "l";
				else if(x == 5 && y > 2)
					return "r";
				else
					return "b";
			}	
			else
				return null;
		}
		public void run()
		{
			while(true)
			{
				SensoryPacket sp = gc.getSensoryPacket();
				String action = think(sp);
				gc.effectorSend(action);
			}
		}
		public static void main(String[] args)
		{
			ReactiveAgent ra = new ReactiveAgent();
			ra.run();
		}
		
}
