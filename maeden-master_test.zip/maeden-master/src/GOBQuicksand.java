///*maedengraphics
import java.awt.*;
//maedengraphics*/

/**
 *@author   Wayne Iba
 *@date:    5-31-05
 *@version: Beta 0.1
 */

public class GOBQuicksand extends GridObject {

    //Constructor sets printchar, color
    public GOBQuicksand(int ix, int iy, int s){
	super(ix,iy,s);
	printChar = 'Q';                   //printchar is Q
	///*maedengraphics
	myColor = new Color(170, 170, 60); //color is tan
	//maedengraphics*/
    }
}

